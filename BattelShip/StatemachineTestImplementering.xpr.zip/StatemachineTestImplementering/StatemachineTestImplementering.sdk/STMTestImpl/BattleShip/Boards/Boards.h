//
// Created by Jonas on 20-12-2018.
//

#ifndef BATTELSHIP_SHIPS_H
#define BATTELSHIP_SHIPS_H

#include "../Logic.h"

#define SHIPS 11
extern char zeros[BOARD_HIGHT][BOARD_WIDTH];

extern char boards[SHIPS][BOARD_HIGHT][BOARD_WIDTH];

#endif //BATTELSHIP_SHIPS_H
