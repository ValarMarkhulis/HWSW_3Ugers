//
// Created by Jonas on 09-01-2019.
//

#ifndef BATTELSHIP_SLAVE_H
#define BATTELSHIP_SLAVE_H

#include <stdio.h>


void slave();
#endif //BATTELSHIP_SLAVE_H
