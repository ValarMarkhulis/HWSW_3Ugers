//
// Created by Jonas on 09-01-2019.
//

#ifndef BATTELSHIP_MASTER_H
#define BATTELSHIP_MASTER_H

#include <stdio.h>

void master();
//void printTilLog(char *string);

#endif //BATTELSHIP_MASTER_H
