/*
 * ip_functions.h
 *
 *  Created on: 23. jan. 2019
 *      Author: casam
 */

#ifndef SRC_AUDIO_IP_FUNCTIONS_H_
#define SRC_AUDIO_IP_FUNCTIONS_H_

#include "xil_types.h"
#include "adventures_with_ip.h"
#include "audio.h"
#include "xscutimer.h"
#include <string.h>
#include "xsdps.h"
#include "platform.h"
#include "xparameters.h"
#include "xil_cache.h"
#include "ff.h"

unsigned char gpio_init();


#define TIMER_LOAD_VALUE	6770
#define INTC_DEVICE_ID		XPAR_SCUGIC_SINGLE_DEVICE_ID

typedef struct WavFileData {
	char chunkID[5];
	u32 chunkSize;
	char format[5];
	char subchunk1ID[5];
	u32 subchunk1Size;
	int audioFormat;
	int numChannels;
	u32 sampleRate;
	u32 byteRate;
	u32 blockAlign;
	int bitsPerSample;
	char subchunk2ID[5];
	u32 subchunk2Size;
	u32 dataOffset;
	u32 dataSize;
} WavHeader;

extern XScuTimer TimerInstance;	/* Cortex A9 Scu Private Timer Instance */

u32 getLittleEndian(int size, FIL * filePtr);
void getBigEndian(char * buf,  FIL * filePtr);
void getParameters(WavHeader * headerPtr, FIL * filePtr);


//static void TimerIntrHandler(void *CallBackRef);
void playAudio(int select);
void load_audio(char * filename, AudioFileInstance * fileInstancePtr);
unsigned char gpio_init();
void audio_stream(XScuTimer * TimerInstancePtr, struct AudioFile * fileInstancePtr);
void startPlayback();
void endPlayback();
unsigned char gpio_init();
int timer_init(XScuGic *IntcInstancePtr, XScuTimer * TimerInstancePtr,u16 TimerDeviceId, u16 TimerIntrId);
u32 getLittleEndian(int size, FIL * file);
void getBigEndian(char * endian,  FIL * file);

void getParameters(WavHeader * headerPtr, FIL * filePtr);


#endif /* SRC_AUDIO_IP_FUNCTIONS_H_ */
