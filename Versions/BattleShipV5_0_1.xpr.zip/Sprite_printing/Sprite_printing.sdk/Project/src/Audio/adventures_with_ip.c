#include "adventures_with_ip.h"
#include "xscutimer.h"
#include "xscugic.h"



//XScuTimer TimerInstance;	/* Cortex A9 Scu Private Timer Instance */


AudioFileInstance explosion;
AudioFileInstance splash;

/*
int AudioInit(u16 TimerDeviceId) {

	xil_printf("Setting up Audio\n");


	load_audio("explo.wav", &explosion);
	load_audio("splash.wav", &splash);


	//Configure the IIC data structure
	xil_printf("Configure the IIC data structure\n");
	IicConfig(XPAR_XIICPS_0_DEVICE_ID);

	//Configure the Audio Codec's PLL

	AudioPllConfig();

	xil_printf("SSM2603 configured\n\r");

	// Initialise GPIO, NCO, and Timer interrupt.
	gpio_init();

	XGpio_DiscreteWrite(&Gpio_audio_enable, 1, 0);


	timer_init(&IntcInstance, &TimerInstance, TIMER_DEVICE_ID, TIMER_IRPT_INTR);

	xil_printf("GPIO and NCO peripheral configured\r\n");

	XGpio_DiscreteWrite(&Gpio_audio_enable, 1, 1);

	sleep(5);

	audio_stream(&TimerInstance, &splash);

	sleep(10);

	audio_stream(&TimerInstance, &explosion);

	sleep(3);

	audio_stream(&TimerInstance, &splash);

	while(1) {}

    return 1;
}
*/



