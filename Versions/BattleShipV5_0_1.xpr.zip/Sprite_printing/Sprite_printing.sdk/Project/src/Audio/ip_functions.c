/*
 * ip_functions.c
 *
 * Contains all functions which pertain to setup and use of IP periperals.
 */

#include "adventures_with_ip.h"
#include "audio.h"
#include "xscutimer.h"
#include <string.h>
#include "xsdps.h"
#include "platform.h"
#include "xparameters.h"
#include "xil_cache.h"
#include "ff.h"

#define TIMER_LOAD_VALUE	6770
#define INTC_DEVICE_ID		XPAR_SCUGIC_SINGLE_DEVICE_ID

typedef struct WavFileData {
	char chunkID[5];
	u32 chunkSize;
	char format[5];
	char subchunk1ID[5];
	u32 subchunk1Size;
	int audioFormat;
	int numChannels;
	u32 sampleRate;
	u32 byteRate;
	u32 blockAlign;
	int bitsPerSample;
	char subchunk2ID[5];
	u32 subchunk2Size;
	u32 dataOffset;
	u32 dataSize;
} WavHeader;

u32 getLittleEndian(int size, FIL * filePtr);
void getBigEndian(char * buf,  FIL * filePtr);
void getParameters(WavHeader * headerPtr, FIL * filePtr);

FIL file;
XScuTimer TimerInstance;	/* Cortex A9 Scu Private Timer Instance */
int subchunk1Address;
int subchunk2Address;
int datachunkAddress;
u32 dataSize;

// SD card variables
static FATFS FS_instance;			// File System instance
FRESULT result;						// FRESULT variable
static const char *Path = "0:/";	// string pointer to the logical drive number

// Sample playback variables
u32 PhaseInc;
u32 val;

u8 data1[400000];
u8 data2[400000];

struct AudioFile * audioFiles[10];

/*
 * The timer interrupt handler manages audio playback.
 */
static void TimerIntrHandler(void *CallBackRef)
{
      XScuTimer *TimerInstancePtr = (XScuTimer *) CallBackRef;
      XScuTimer_ClearInterruptStatus(TimerInstancePtr);

      if (audioFiles[0]->playing == 1) {
    	  //xil_printf("Playing!\n");
		  if (audioFiles[0]->phaseInc >= audioFiles[0]->size) {
			//XScuTimer_Stop(TimerInstancePtr);
			audioFiles[0]->playing = 0;
			audioFiles[0]->phaseInc = 0;
		  }

		  if (audioFiles[1]->phaseInc < 10 && audioFiles[1]->phaseInc > 0) {
			  xil_printf("Audio file two is playing/not playing: %d\n", audioFiles[1]->playing);
		  }

		  // Due to the wave file being divided into chunks of 8-bits each three successive bytes
		  // have to be concatenated so that a 24 bit variable is gotten.
		  val = ( audioFiles[0]->dataPtr[ audioFiles[0]->phaseInc ] << 16 ) \
				  | (audioFiles[0]->dataPtr[ audioFiles[0]->phaseInc + 1 ] << 8 ) \
				  | audioFiles[0]->dataPtr[ audioFiles[0]->phaseInc + 2 ];
      }

      if (audioFiles[1]->playing == 1) {
          	  //xil_printf("Playing!\n");
      		  if (audioFiles[1]->phaseInc >= audioFiles[1]->size) {
      			//XScuTimer_Stop(TimerInstancePtr);
      			audioFiles[1]->playing = 0;
      			audioFiles[1]->phaseInc = 0;
      		  }

      		  // Due to the wave file being divided into chunks of 8-bits each three successive bytes
      		  // have to be concatenated so that a 24 bit variable is gotten.
      		  val += ( audioFiles[1]->dataPtr[ audioFiles[1]->phaseInc ] << 16 ) \
      				  | (audioFiles[1]->dataPtr[ audioFiles[1]->phaseInc + 1 ] << 8 ) \
      				  | audioFiles[1]->dataPtr[ audioFiles[1]->phaseInc + 2 ];
            }

      if (audioFiles[2]->playing == 1) {
               	  //xil_printf("Playing!\n");
           		  if (audioFiles[2]->phaseInc >= audioFiles[2]->size) {
           			//XScuTimer_Stop(TimerInstancePtr);
           			audioFiles[2]->playing = 0;
           			audioFiles[2]->phaseInc = 0;
           		  }

           		  // Due to the wave file being divided into chunks of 8-bits each three successive bytes
           		  // have to be concatenated so that a 24 bit variable is gotten.
           		  val += ( audioFiles[2]->dataPtr[ audioFiles[2]->phaseInc ] << 16 ) \
           				  | (audioFiles[2]->dataPtr[ audioFiles[2]->phaseInc + 1 ] << 8 ) \
           				  | audioFiles[2]->dataPtr[ audioFiles[2]->phaseInc + 2 ];
                 }

	  Xil_Out32(I2S_DATA_TX_R_REG, val);
	  Xil_Out32(I2S_DATA_TX_L_REG, val);

	  audioFiles[0]->phaseInc += 3;
	  audioFiles[1]->phaseInc += 3;

}

/*
 * Load a specified audio file from SD card.
 */
void load_audio(char * filename, AudioFileInstance * fileInstancePtr) {

	xil_printf("Loads audiofile: %s...", filename);
	WavHeader fileHeader;
	int i, readCount;
	u8 buffer[10];
	u32 counter = 0;
	FRESULT result;

	result = f_mount(&FS_instance, Path, 1);
	if(result != FR_OK) {
		xil_printf("SD_mount FAILCODE: %d\n", result);
	}

	result = f_open(&file, filename, FA_READ );
	if(result != FR_OK) {
		xil_printf("SD_open FAILCODE: %d\n", result);
	}

	getParameters(&fileHeader, &file);
	dataSize = fileHeader.dataSize;

	//fileInstancePtr = createAudioFile(fileInstancePtr, fileHeader.chunkSize);

	//xil_printf("Chunk ID: %s\nChunk size: %d\nFormat: %s\nSubchunk 1 ID: %s\nSubchunk 1 size: %d\n", \
	//		fileHeader.chunkID, fileHeader.chunkSize, fileHeader.format, fileHeader.subchunk1ID, fileHeader.subchunk1Size);

	//xil_printf("Data size size: %d\nData offset: 0x%x\n", \
	//		fileHeader.dataSize, fileHeader.dataOffset);

	//xil_printf("Sample rate: %d\nNumber of channels: %d\nAudio format: %d\n", fileHeader.sampleRate, fileHeader.numChannels, fileHeader.audioFormat);

	//xil_printf("Loading!\n");

	for (i = 0; i < 10; i++) {
		if (audioFiles[i] == 0) {
			audioFiles[i] = fileInstancePtr;
			xil_printf("File allocated to struct #%d\n", i);
			break;
		}
	}

	result = f_close(&file);
	if(result != FR_OK) {
		xil_printf("SD_close FAILCODE: %d\n", result);
	}


	result = f_open(&file, filename, FA_READ );
	if(result != FR_OK) {
		xil_printf("SD_open2 FAILCODE: %d\n", result);
	}


	f_lseek(&file, 0x52);
	audioFiles[i]->phaseInc = 0;
	audioFiles[i]->playing = 0;
	audioFiles[i]->size = fileHeader.dataSize;

	while (counter < fileHeader.dataSize) {
		f_read(&file, buffer, 3, (UINT*)&readCount);

		if (readCount != 3) {
			//xil_printf("Error reading! %d/3 bytes read.", readCount);
		}

		if (i == 0) {
			data1[counter] = buffer[0];
			data1[counter+1] = buffer[1];
			data1[counter+2] = buffer[2];
		} else {
			data2[counter] = buffer[0];
			data2[counter+1] = buffer[1];
			data2[counter+2] = buffer[2];
		}

		if (counter % 5000 == 0) {
			//xil_printf("Assigned values %d/%d\n", counter, fileHeader.dataSize);
		}

		counter += 3;
	}

	if (i == 0) {
		audioFiles[i]->dataPtr = data1;
	} else {
		audioFiles[i]->dataPtr = data2;
	}
	result = f_sync(&file);
	if(result != FR_OK) {
		xil_printf("SD_sync FAILCODE: %d\n", result);
	}

	result = f_close(&file);
	if(result != FR_OK) {
		xil_printf("SD_close2 FAILCODE: %d\n", result);
	}

	result = f_mount(&FS_instance, Path, 1);
	if(result != FR_OK) {
		xil_printf("SD_unmount FAILCODE: %d\n", result);
	}


	xil_printf("Done!\n\r");


}

/*
 * Start streaming audio.
 *
 * This function turns on the timer.
 */
void audio_stream(XScuTimer * TimerInstancePtr, struct AudioFile * fileInstancePtr) {
	init_platform();
	fileInstancePtr->playing = 1;
	fileInstancePtr->phaseInc = 0;

	if (!TimerInstancePtr->IsStarted) {
		XScuTimer_Start(TimerInstancePtr);
		xil_printf("Timer started");
	}
}

void playAudio(int select) {
	switch(select) {
	case 1:
		audio_stream(&TimerInstance , &explosion);
		break;
	}
}


void startPlayback();

void endPlayback();

unsigned char gpio_init() {
	int Status;

	Status = XGpio_Initialize(&Gpio_audio_enable, AUDIO_ENABLE_ID);
	if(Status != XST_SUCCESS) return XST_FAILURE;

	XGpio_SetDataDirection(&Gpio_audio_enable, 1, 0x00);

	return XST_SUCCESS;
}



/*
 * Enable timer interrupts.
 */
int timer_init(XScuGic *IntcInstancePtr, XScuTimer * TimerInstancePtr,
	u16 TimerDeviceId, u16 TimerIntrId) {

	XScuGic_Config *IntcConfig;
	XScuTimer_Config *ConfigPtr;

	//XScuGic_Disconnect(IntcInstancePtr, TimerIntrId);

	int Status;

	ConfigPtr = XScuTimer_LookupConfig(TimerDeviceId);

	Status = XScuTimer_CfgInitialize(TimerInstancePtr, ConfigPtr,
						ConfigPtr->BaseAddr);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = XScuTimer_SelfTest(TimerInstancePtr);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	IntcConfig = XScuGic_LookupConfig(INTC_DEVICE_ID);
	if (NULL == IntcConfig) {
		return XST_FAILURE;
	}

	Status = XScuGic_CfgInitialize(IntcInstancePtr, IntcConfig,
						IntcConfig->CpuBaseAddress);

	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Xil_ExceptionInit();

	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_IRQ_INT,
					(Xil_ExceptionHandler)XScuGic_InterruptHandler,
					IntcInstancePtr);

	Status = XScuGic_Connect(IntcInstancePtr, TimerIntrId,
					(Xil_ExceptionHandler)TimerIntrHandler,
					(void *)TimerInstancePtr);

	if (Status != XST_SUCCESS) {
		return Status;
	}

	XScuGic_Enable(IntcInstancePtr, TimerIntrId);

	XScuTimer_EnableInterrupt(TimerInstancePtr);

	Xil_ExceptionEnable();

	XScuTimer_EnableAutoReload(TimerInstancePtr);
	XScuTimer_LoadTimer(TimerInstancePtr, TIMER_LOAD_VALUE);

	return XST_SUCCESS;
}

/*
 * Returns a little endian encoded number (either two or four bytes) from file.
 */
u32 getLittleEndian(int size, FIL * file) {
	u8 buf [10];
	u32 readCount = 0;

	f_read(file, buf, size, (UINT*)&readCount);

	if (readCount != size) {
		xil_printf("Error! Read %d of %d bytes.\n", readCount, size);
	}

	// Read bytes in reverse order
	if (size == 2) {
		return (u32)( (buf[1] << 8 ) | buf[0] );
	} else if (size == 4) {
		return (buf[3] << 24 ) \
				| (buf[2] << 16 ) | (buf[1] << 8 ) \
				| (buf[0]);
	} else {
		return -1;
	}
}

/*
 * Returns a big endian encoded string (either two or four bytes) from file.
 */
void getBigEndian(char * endian,  FIL * file) {
	int i;
	u8 buf[10];
	u32 readCount = 0;

	f_read(file, buf, 4, (UINT*)&readCount);

	if (readCount != 4) {
		xil_printf("Error! Read %d of 4 bytes.\n", readCount);
	}

	for (i = 0; i < 4; i++) {
		endian[i] = buf[i];
	}
}

/*
 * Reads and saves the specified file's header.
 */
void getParameters(WavHeader * headerPtr, FIL * filePtr) {
	char buf[5] = "";

	getBigEndian(buf, filePtr);
	strcpy(headerPtr->chunkID, buf);

	headerPtr->chunkSize = getLittleEndian(4, filePtr);
	//subchunk1Address = chunkAddress + headerPtr->chunkSize;

	getBigEndian(buf, filePtr);
	strcpy(headerPtr->format, buf);

	getBigEndian(buf, filePtr);
	strcpy(headerPtr->subchunk1ID, buf);

	// Get the size of subchunk one and use it to compute
	// the address of subchunk two.
	headerPtr->subchunk1Size = getLittleEndian(4, filePtr);
	subchunk2Address = 20 + headerPtr->subchunk1Size;

	headerPtr->audioFormat = getLittleEndian(2, filePtr);
	headerPtr->numChannels = getLittleEndian(2, filePtr);

	headerPtr->sampleRate = getLittleEndian(4, filePtr);
	headerPtr->byteRate = getLittleEndian(4, filePtr);
	headerPtr->blockAlign = getLittleEndian(2, filePtr);
	headerPtr->bitsPerSample = getLittleEndian(2, filePtr);

	// Jump to subchunk two.
	f_lseek(filePtr, subchunk2Address);

	getBigEndian(buf, filePtr);

	// If the string at this location doesn't specify data...
	if ( strncmp(buf, "data", 4) != 0 ) {
		//xil_printf("\nDid not find a data tag at this location.\n");

		strcpy(headerPtr->subchunk2ID, buf);
		headerPtr->subchunk2Size = getLittleEndian(4, filePtr);

		//xil_printf("Subchunk 2 size: %d\n", headerPtr->subchunk2Size);

		f_lseek(filePtr, subchunk2Address + headerPtr->subchunk2Size + 8);

		getBigEndian(buf, filePtr);

		if ( strncmp(buf, "data", 4) != 0 ) {
			//xil_printf("Error! Data could not be found");
		} else {
			//xil_printf("\nData tag found at this location. %s\n", buf);
			headerPtr->dataSize = getLittleEndian(4, filePtr);
			headerPtr->dataOffset = (subchunk2Address + headerPtr->subchunk2Size + 16);
		}
	} else {
		//xil_printf("\nData tag found at this location. %s\n", buf);

		headerPtr->dataOffset = subchunk2Address;
	}

}
