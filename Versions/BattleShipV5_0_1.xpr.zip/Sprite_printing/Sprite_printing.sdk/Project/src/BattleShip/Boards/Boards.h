
#ifndef BATTELSHIP_SHIPS_H
#define BATTELSHIP_SHIPS_H

#include "../Logic.h"

#define SHIPS 27
extern unsigned char zeros[BOARD_HIGHT][BOARD_WIDTH];

extern unsigned char boards[SHIPS][BOARD_HIGHT][BOARD_WIDTH];

#endif //BATTELSHIP_SHIPS_H
