//
// Created by Jonas on 20-12-2018.
//
#include <stdio.h>
#ifndef BATTELSHIP_LOGIC_H
#define BATTELSHIP_LOGIC_H

#define BOARD_WIDTH 10
#define BOARD_HIGHT 10

// Variabels:
enum GAMESTATUS{OVER = 0, RUNNING = 1, READY};  // Not used
struct PlayerInfo {
    int p1Board;
    int p2Board;
    int p1Turns;
    int p2Turns;
    int p1Shots;
    int p2Shots;
} playerInfo;

struct cursor_struct {
    int x;
    int y;
    //int pressed:1;
} cursor;

int shipsLeft[2];
extern int mode;
extern int player;
extern int enterFlag;
extern int enterReleasedFlag;
extern int playersTurn;
extern int enemyHitsCounter;
extern int playerHits;

extern unsigned char ships[2][BOARD_WIDTH][BOARD_HIGHT];
extern unsigned char shots[2][BOARD_WIDTH][BOARD_HIGHT];

extern int joystickSet;

// Functions to setup:
void zeroBoards();
int randomStart();  // Not random yet..
void setupGame(int b1, int b2);
void selectBoardFromCursor(); // For cursor implementation


// General functions:
void printBoardTerm(int choice);
void printField(unsigned char c);

void CursorMove(int x, int y);

void getCoordinatesFromTerm(char * shot);
void getCoordinatesFromCursor(char * shot);


// Used during the game:
int playerTurn(char *shot, int player);
int OtherplayerTurn(char *shot, int player);
char checkWinner(int player);

int shotLegal(int player, char * shot);
int shootAt(int player, char * shot);


// Legacy
int runGame();

#endif //BATTELSHIP_LOGIC_H
