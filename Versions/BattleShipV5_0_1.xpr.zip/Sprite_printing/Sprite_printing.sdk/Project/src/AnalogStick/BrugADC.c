/*
 * BrugADC.c
 *
 *  Created on: 17. jan. 2019
 *      Author: casam
 *
 *  This demo will use the ADC with the following setup and settings:
 *
 *  Input ports for signals:
 *  AD7		: Vaux7 (N15)
 *  AD14	: Vaux14 (L14)
 *  AD15	: Vaux15 (K16)
 *  (Remember that the ADC can only get between 0-1V!!!!!)
 *
 *	Input ports that should be grounded!: (The pmod ports under the input ports)
 *	N16
 *	L15
 *	J16
 *	>They should be grounded because the ADC should be provided with a signal and ground.
 *
 *	Basic:
 *		*Interface Options
 *			AXI4Lite
 *		*Timing Mode
 *			Continuous Mode
 *		*Startup Channel Selection
 *			Channel Sequencer
 *		Everything else on std values
 *
 *  ADC Setup:
 *  	(The following is selected)
 *  	Sequencer Mode: Continuous Mode
 *  	Channel Averaging : 16
 *
 *  		ADC Calibration:
 *  			ADC Offset and Gain Calibration
 *  			Enable CALIBRATION Averaging
 *
 *  Non alarms set
 *
 *  Channel Sequencer
 *  	(The following under "Channel Enable" is checked)
 *  	vauxp7/vauxn7
 *  	vauxp7/vauxn14
 *  	vauxp7/vauxn15
 *
 */


#include "xparameters.h"
#include "xadcps.h"
#include "xstatus.h"
#include "stdio.h"
#include "xgpio.h"
#include "xscugic.h"
#include "xil_exception.h"
#include "xil_printf.h"
#include "ADC.h"

#define printf xil_printf /* Small foot-print printf function */


int main3(){
	int status = 0;
	status = xADCSetup();
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	char returnValue = 0;
	int tester = 1;
	while(tester == 1){
		returnValue = XAdcPolledPrintfExample2();
		printf("%d!\n", (int) returnValue);
	}

	printf("test");
	return 0;
}
