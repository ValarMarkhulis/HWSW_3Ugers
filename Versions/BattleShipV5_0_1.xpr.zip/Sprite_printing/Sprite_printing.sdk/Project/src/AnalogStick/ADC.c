/*
 * ADC.c
 *
 * The functions are taken from
 * http://realisenow.sdu.dk/using-the-xadc-on-the-zybo-board/
 */

#include "xparameters.h"
#include "xadcps.h"
#include "xstatus.h"
#include "stdio.h"
#include "xgpio.h"
#include "xscugic.h"
#include "xil_exception.h"
#include "xil_printf.h"
#include "ADC.h"
#include "sleep.h"

/************************** Constant Definitions ****************************/

/*
 * The following constants map to the XPAR parameters created in the
 * xparameters.h file. They are defined here such that a user can easily
 * change all the needed parameters in one place.
 */
#define XADC_DEVICE_ID 		XPAR_XADCPS_0_DEVICE_ID

/***************** Macros (Inline Functions) Definitions ********************/

// converting RAW data from external sourse to voltage
#define XAdcPs_ExternalRawToVoltage(AdcData)\
								((((float)(AdcData))* (1.0f))/65536.0f)


/************************** Variable Definitions ****************************/

static XAdcPs XAdcInst;      /* XADC driver instance */
XAdcPs *XAdcInstPtr;

/****************************************************************************/


/****************************************************************************/
/*
*
* This function converts the fraction part of the given floating point number
* (after the decimal point)to an integer.
*
* @param	FloatNum is the floating point number.
*
* @return	Integer number to a precision of 3 digits.
*
* @note
* This function is used in the printing of floating point data to a STDIO device
* using the xil_printf function. The xil_printf is a very small foot-print
* printf function and does not support the printing of floating point numbers.
*
* This function is taken from
* http://realisenow.sdu.dk/using-the-xadc-on-the-zybo-board/
*****************************************************************************/
int XAdcFractionToInt2(float FloatNum)
{
	float Temp;

	Temp = FloatNum;
	if (FloatNum < 0) {
		Temp = -(FloatNum);
	}

	return( ((int)((Temp -(float)((int)Temp)) * (1000.0f))));
}

/****************************************************************************/
/**This function will return a char, where the following bit positions
 * is set:
 * 0 - No joystick input
 * 1 - The joystick is pointing up (x-axis change)
 * 2 - The joystick is pointing down (x-axis change)
 * 3 - The joystick is pointing left (y-axis change)
 * 4 - The joystick is pointing right (y-axis change)
 * 5 - The joystick button has been pressed
 *
 * The function is taken from
 * http://realisenow.sdu.dk/using-the-xadc-on-the-zybo-board/
****************************************************************************/
char XAdcPolledPrintfExample2()
{

	u32 VccPdroRawData;
	float VccPintData;
	char returnValue = 0;




		 /*
		 * Read the AD14 input Voltage Data from the
		 * ADC data registers.
		 */
		VccPdroRawData = XAdcPs_GetAdcData(XAdcInstPtr, XADCPS_CH_AUX_MIN+14);
		VccPintData = XAdcPs_ExternalRawToVoltage(VccPdroRawData);
		if(XAdcFractionToInt2(VccPintData) > 700){
			xil_printf("The x stick is down\r\n");
			returnValue |= 1;
		}else if(XAdcFractionToInt2(VccPintData) < 300){
			xil_printf("The x stick is up\r\n");
			returnValue |= 2;
		}else{
			//
		}


		/*
		 * Read the AD7 input Voltage Data from the
		 * ADC data registers.
		 */
		VccPdroRawData = XAdcPs_GetAdcData(XAdcInstPtr, XADCPS_CH_AUX_MIN+7);
		VccPintData = XAdcPs_ExternalRawToVoltage(VccPdroRawData);
		if(XAdcFractionToInt2(VccPintData) > 700){
			xil_printf("The Y stick is left\r\n");
			returnValue |= 4;
		}else if(XAdcFractionToInt2(VccPintData) < 300){
			xil_printf("The Y stick is right\r\n");
			returnValue |= 8;
		}else{
			//
		}


		/*
		 * Read the AD15 input Voltage Data from the
		 * ADC data registers.
		 */
		VccPdroRawData = XAdcPs_GetAdcData(XAdcInstPtr, XADCPS_CH_AUX_MIN+15);
		VccPintData = XAdcPs_ExternalRawToVoltage(VccPdroRawData);
		if(XAdcFractionToInt2(VccPintData) > 100){
			//xil_printf("The switch is not pressed\r\n");
		}else{
			returnValue |= 16;
			xil_printf("The switch is pressed\r\n");
		}
		usleep(200000);
	return returnValue;
}

/****************************************************************************/
/**This function will setup and do a selftest of the ADC
 *
 * The function is taken from
 * http://realisenow.sdu.dk/using-the-xadc-on-the-zybo-board/
****************************************************************************/
int xADCSetup(){
	int Status;
	XAdcPs_Config *ConfigPtr;
	XAdcInstPtr = &XAdcInst;

	xil_printf("\r\nEntering the XAdc Polled Example. \r\n");
	/*
	 * Initialize the XAdc driver.
	 */
	ConfigPtr = XAdcPs_LookupConfig(XADC_DEVICE_ID);
	if (ConfigPtr == NULL) {
		return XST_FAILURE;
	}
	XAdcPs_CfgInitialize(XAdcInstPtr, ConfigPtr,
				ConfigPtr->BaseAddress);

	/*
	 * Self Test the XADC/ADC device
	 */
	Status = XAdcPs_SelfTest(XAdcInstPtr);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	return XST_SUCCESS;
}
