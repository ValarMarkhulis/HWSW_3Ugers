/*
 * ADC.h
 *
 *  Created on: 17. jan. 2019
 *      Author: casam
 */

#ifndef SRC_ADC_H_
#define SRC_ADC_H_

int XAdcFractionToInt2(float FloatNum);
char XAdcPolledPrintfExample2();
int xADCSetup();


#endif /* SRC_ADC_H_ */
